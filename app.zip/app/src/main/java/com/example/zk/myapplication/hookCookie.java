package com.example.zk.myapplication;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.lang.ref.WeakReference;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.Map;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Created by zk on 2017/8/24.
 */

public class hookCookie {

    public static void replaceClassLoader(Context context, String my_packageName) {
        try {
            Class<?> aClass = Class.forName("android.app.ActivityThread");
            Class<?> aClass1 = Class.forName("android.app.LoadedApk");

            Object currentActivityThread = aClass.getMethod("currentActivityThread").invoke(new Object[]{});


            Field mPackages = aClass.getDeclaredField("mPackages");
            mPackages.setAccessible(true);
            Map map = (Map) mPackages.get(currentActivityThread);
            WeakReference o = (WeakReference) map.get(context.getPackageName());
            Object loadedapk = o.get();
            Field mClassLoader = aClass1.getDeclaredField("mClassLoader");
            mClassLoader.setAccessible(true);


            Object classLoader = mClassLoader.get(loadedapk);
            Class clzBaseDexClassLoader = Class.forName("dalvik.system.BaseDexClassLoader");
            Class clzDexPathList = Class.forName("dalvik.system.DexPathList");
            Field field_pathList = clzBaseDexClassLoader.getDeclaredField("pathList");
            field_pathList.setAccessible(true);
            Object dexPathList = field_pathList.get(classLoader);
            Field field_dexElements = clzDexPathList.getDeclaredField("dexElements");
            field_dexElements.setAccessible(true);
            Class clzElement = Class.forName("dalvik.system.DexPathList$Element");
            Object dexElemennts = field_dexElements.get(dexPathList);

            //int cookie=MmClassLoader.getcookie();
            int length = Array.getLength(dexElemennts);

            for (int i = 0; i < length; i++) {
                Object ele = Array.get(dexElemennts, i);

                try {
                    Field field_dexFile = clzElement.getDeclaredField("dexFile");
                    field_dexFile.setAccessible(true);
                    Object dexFile = field_dexFile.get(ele);

                    Class clzDexFile = Class.forName("dalvik.system.DexFile");
                    Field field_mcookie = clzDexFile.getDeclaredField("mCookie");
                    field_mcookie.setAccessible(true);
                    //field_mcookie.set(dexFile, mCookie);
                    int o1 = (int) field_mcookie.get(dexFile);
                    Log.e("wodelog","o1---- "+o1);
                    XposedBridge.log("cookie: "+o1);

                    MainActivity.aaattachBaseContext(o1,my_packageName);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void hookCookie(final XC_LoadPackage.LoadPackageParam lpparam) {
        // 判断是否是要Hook的包名
        final String packageName = lpparam.packageName;

        StringBuffer sb = null;
        try {
            File file = new File("/sdcard/tuoke.txt");
            BufferedReader br = new BufferedReader(new FileReader(file));
            String readline = "";
            sb = new StringBuffer();
            while ((readline = br.readLine()) != null) {
                System.out.println("readline:" + readline);
                sb.append(readline);
            }
            br.close();
            System.out.println("读取成功：" + sb.toString());
        } catch (Exception e) {

            e.printStackTrace();

        }

        if(sb==null){
            return;
        }

       String result=sb.toString();




        String[] split = result.split("::");


        final String  my_packageName=split[0];
        final String protect_Application=split[1];
        final String Main_Activity=split[2];

        /*XposedHelpers.findAndHookMethod("android.app.Activity", lpparam.classLoader, "finish", new XC_MethodReplacement() {

            @Override
            protected Object replaceHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                XposedBridge.log("阻止finish");
                return null;
            }
        });*/
         final boolean[] ishasClassLoader = {false};
        // 可以Hook了
        if(packageName.equals(my_packageName)){
            XposedBridge.log("可以 hook cookie");


           /* try {
                XposedHelpers.findAndHookMethod(protect_Application, lpparam.classLoader, "onCreate",  new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {

                        ClassLoader xx= (ClassLoader) XposedHelpers.getObjectField(param.thisObject,"cl");
                        Context context = (Context) param.thisObject;
                        XposedBridge.log("我拿到ClassLoader了");
                        ishasClassLoader[0] =true;
                        ClassLoader classLoader =context.getClassLoader();
                        XposedHelpers.findAndHookMethod(Main_Activity, classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                XposedBridge.log("我进入真正的onCreate了");
                                replaceClassLoader((Context) param.thisObject,my_packageName);

                            }
                        });

                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }*/
            XposedBridge.log("------------"+Main_Activity);



            XposedHelpers.findAndHookMethod(protect_Application, lpparam.classLoader, "attachBaseContext", Context.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {

                    Context context = (Context) param.args[0];
                    XposedBridge.log("我拿到ClassLoader了");
                    ClassLoader classLoader =context.getClassLoader();
                    XposedHelpers.findAndHookMethod(Main_Activity, classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            XposedBridge.log("我进入真正的onCreate了");
                            replaceClassLoader((Context) param.thisObject,my_packageName);

                        }
                    });

                }
            });


            while (XposedHelpers.findClass(Main_Activity, lpparam.classLoader)==null){
                continue;
            }


            XposedHelpers.findAndHookMethod(Main_Activity, lpparam.classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    XposedBridge.log("我进入真正的onCreate了");
                    replaceClassLoader((Context) param.thisObject,my_packageName);

                }
            });

               /*  if(ishasClassLoader[0] ==false){
                XposedHelpers.findAndHookMethod(Main_Activity, lpparam.classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        XposedBridge.log("我进入真正的onCreate了");
                        replaceClassLoader((Context) param.thisObject,my_packageName);

                    }
                });
            }*/




          /*  XposedHelpers.findAndHookMethod(DexFile.class.getName(), lpparam.classLoader, "loadDex",String.class, String.class, int.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            if (!param.hasThrowable()) {
                                int falg = (Integer) param.args[2];
                                String sourcePathName = (String) param.args[0];
                                String outputPathName = (String) param.args[1];
                                XposedBridge.log("sourcePathName:" + sourcePathName + " outputPathName:" + outputPathName + " falg:" + falg);
                                Object object = param.getResult();
                                if (object instanceof DexFile) {
                                    Field field = ((DexFile) object).getClass().getDeclaredField("mCookie");
                                    field.setAccessible(true);
                                    int cookie = field.getInt(object);
                                    field.setAccessible(false);
                                    XposedBridge.log("cookie:" + String.format("%x", cookie));
                                    //MainActivity.aaattachBaseContext(cookie,my_packageName);

                                    Thread thread = new Thread(new dumpThread(cookie,my_packageName,Main_Activity,lpparam.classLoader));
                                    thread.start();
                                }
                            }
                        }
                    });*/

        }

    }
    static {
        System.load("/data/data/com.example.zk.myapplication/lib/libzkjg-lib.so");
    }

   /* static class dumpThread implements Runnable {
        int cookide;
        String my_packageName;
        String Main_Activity;
        ClassLoader classLoader;
        public dumpThread(int cookide1, String myPackageName1, String Main_Activity1,  ClassLoader classLoader1){
            this.cookide=cookide1;
            this.my_packageName=myPackageName1;
            this.Main_Activity=Main_Activity1;
            this.classLoader= classLoader1;
        }

        @Override
        public void run() {
            try {
                Thread.sleep(15000);//休眠5s 时间足够壳修复dex
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            XposedBridge.log("我yao了");
            MainActivity.aaattachBaseContext(cookide,my_packageName);

            XposedHelpers.findAndHookMethod(Main_Activity, classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    XposedBridge.log("我进入真正的onCreate了");
                    replaceClassLoader((Context) param.thisObject,my_packageName);

                }
            });
        }
    }*/

}
